package in.ineuron.Main;

import in.ineuron.Controller.UtilControllerClass;

public class MainClass {
	
	public static void main(String[] args) {
		UtilControllerClass.Return();
	
	}
      }
	

