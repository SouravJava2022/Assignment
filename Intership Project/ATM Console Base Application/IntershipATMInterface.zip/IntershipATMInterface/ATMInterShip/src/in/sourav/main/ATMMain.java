package in.sourav.main;

import java.util.Scanner;

import in.sourav.controller.ATMOfTheBanks;
import in.sourav.controller.AccHolder;
import in.sourav.controller.AccNo;
import in.sourav.controller.BankNames;
import in.sourav.controller.BankTransaction;

public class ATMMain {

	public static void main(String[] args) {
		//User Id And Password
		int userid=123456;
		String password="123";
		
		Scanner scan = new Scanner(System.in);
		System.out.println("************Welcome To SBI Bank*************");
		System.out.println("******Please Enter User id:******");
		int user = scan.nextInt();
		System.out.println("******Please Enter Pin:*********");
		String pass = scan.next();
		//Object Creation of BankTransaction Class
		BankTransaction transaction = new BankTransaction();
		
		//Setting the Static Variable Name
		BankNames.setBankName("SBI");
		ATMOfTheBanks.setATMofBank("SBI");
		AccHolder.setAccHolderName("SOURAV");
		AccNo.setAccno(336545987);
		
		//Using Condition
		if ((user==userid) && (pass.equalsIgnoreCase(password))) {
			
			System.out.println("**********Logging Sucessfull************");
			
			//calling Method
			transaction.switchMethod();
			
		} else {
            System.out.println("**************Logging Failed please Enter Right Things*********** ");
		}
		
	}

}
