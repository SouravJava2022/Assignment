package in.sourav.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class BankTransaction {
	int bankbalanceAmount;
	Scanner scan=null;
	ArrayList<String> list = new ArrayList<String>();
	AccNo accNo=null;
	
	//this is Common method
	public int commonMethod() {
		System.out.println("1. Deposit\n2. WithDraw\n3. Transfer\n4. Transaction History\n5. Quit");
		scan = new Scanner(System.in);
		System.out.println("*****Enter Option*****");
		int option = scan.nextInt();
		return option;
	}
	public void switchMethod() {
		int i = commonMethod();
		switch (i) {
		case 1:{
			      deposit();
			break;
		}
		case 2:{
			   withdraw();
			break;
		}
		case 3:{
			transfer();
			break;
		}
		case 4:{
			transactionHistory();
			break;
		}
		case 5:{
			quit();
			break;
		}
		default:System.out.println("********You Enter Wrong Option*********");
			
		}
	}
	
	// This Is Also A Common Method for Continue running
	public void commonMethod2() {
		System.out.println("****Are You Want To Continue YES/NO******");
		String next = scan.next();
		if(next.equalsIgnoreCase("yes")) {
			switchMethod();
		}
		else {
			System.out.println("******Come Back Again*******");
		}
	}
	
	//This is deposit Mathod
	public void deposit() {
		System.out.println("*********Please Enter Deposit Amount:-***********");
		int depositAmount = scan.nextInt();
		
		if(depositAmount>0) {
        bankbalanceAmount=depositAmount+bankbalanceAmount;
         accNo= new AccNo();
        accNo.setAccBalance(bankbalanceAmount);
        System.out.println(accNo.getAccBalance());
        
        list.add("*****Amount Deposited and available Balance is:***** "+accNo.getAccBalance());
        
        commonMethod2();
		}
		else {
			System.out.println("******Please Enter Positive Amount*******");
		}
			
	}
	
	//This is WithDraw Method
	public void withdraw() {
		System.out.println("******Please Enter Withdraw Amount*****");
		int withdrawAmount = scan.nextInt();
		if((accNo.getAccBalance()-withdrawAmount)>0) {
			bankbalanceAmount=bankbalanceAmount-withdrawAmount;
			accNo.setAccBalance(bankbalanceAmount);
			System.out.println("Available Balance is:: "+accNo.getAccBalance());
			
			list.add("******Money Debited and Take Cash From ATM amount::*******"+withdrawAmount);
			commonMethod2();
		}
		else {
			System.out.println("********Please Enter Right Withdraw Amount or Deposit Amount First******");
		}
	}
	//This Is Transfer Method
	public void transfer() {
		System.out.println("**********Please Enter AccNo to which Money Will Be Credited **********");
		long accNoTo = scan.nextLong();
		System.out.println("******Please Enter Amount*********");
		int amount = scan.nextInt();
		
		if((accNo.getAccBalance()-amount>0)) {
			bankbalanceAmount=bankbalanceAmount-amount;
			accNo.setAccBalance(bankbalanceAmount);
			System.out.println("Available Balance is:: "+accNo.getAccBalance());
			System.out.println("Transfer SucessFull ...........");
			
			list.add("****Trasfer Money From*****"+BankNames.getBankName()+"***AccHolder***"+AccHolder.getAccHolderName()+"***AccNo***"+AccNo.getAccno()+"****Transfer To*****"+accNoTo+"**** With Amount*** "+amount);
			
			commonMethod2();
		}
		else {
			System.out.println("********Please Enter Right Transfer Amount or Deposit Amount First************");
		}
		
	}
	//This Is Trasnsaction Method
	public void transactionHistory() {
		if(list.isEmpty()) {
			System.out.println("******Please Make Transacton********");
			commonMethod2();
		}
		else {
			System.out.println("************Transaction History Started*********** ");
		Iterator<String> iterator = list.iterator();
		
		while(iterator.hasNext()) {
			String next = iterator.next();
			System.out.println(next);
		}
		System.out.println("***********Transaction History Ended**************");
		commonMethod2();
		}
}
	//This Is Quit Method
	public void quit() {
		System.out.println("******Come Again********");
	}
}
