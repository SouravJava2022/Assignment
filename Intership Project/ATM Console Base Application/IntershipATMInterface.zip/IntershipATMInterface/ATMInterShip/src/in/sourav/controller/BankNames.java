package in.sourav.controller;

public class BankNames {
	
	private static String bankName;

	public static String getBankName() {
		return bankName;
	}
	
	public static void setBankName(String bankName) {
		BankNames.bankName = bankName;
	}

	@Override
	public String toString() {
		return "BankNames []";
	}
}
