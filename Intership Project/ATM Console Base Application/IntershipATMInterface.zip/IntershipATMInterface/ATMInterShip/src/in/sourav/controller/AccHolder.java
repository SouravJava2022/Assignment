package in.sourav.controller;

public class AccHolder {
       private static String AccHolderName;

	public static String getAccHolderName() {
		return AccHolderName;
	}

	public static void setAccHolderName(String accHolderName) {
		AccHolderName = accHolderName;
	}

	@Override
	public String toString() {
		return "AccHolder [AccHolderName=" + AccHolderName + "]";
	}
}
