package in.sourav.controller;

public class ATMOfTheBanks {
    private static String ATMofBank;

	public static String getATMofBank() {
		return ATMofBank;
	}

	public static void setATMofBank(String aTMofBank) {
		ATMofBank = aTMofBank;
	}
	@Override
	public String toString() {
		return "ATMOfTheBanks [ATMofBank=" + ATMofBank + "]";
	}
}
