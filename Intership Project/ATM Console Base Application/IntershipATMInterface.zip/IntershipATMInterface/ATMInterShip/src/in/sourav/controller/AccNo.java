package in.sourav.controller;

public class AccNo {
       private static long Accno;
       private long AccBalance;
       
	public static long getAccno() {
		return Accno;
	}
	public long getAccBalance() {
		return AccBalance;
	}

	public void setAccBalance(long accBalance) {
		AccBalance = accBalance;
	}
	public static void setAccno(long accNo) {
		Accno = accNo;
	}
	@Override
	public String toString() {
		return "AccNo [AccNo=" + Accno + "]";
	}
}
