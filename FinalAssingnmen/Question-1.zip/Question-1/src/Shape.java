
public interface Shape {
    void area();
    void perimeter();
}
