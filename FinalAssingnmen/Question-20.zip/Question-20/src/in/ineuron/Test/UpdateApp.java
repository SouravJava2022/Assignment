/*
 * 20. The program should use Hibernate to map the table to a Java object and then update
     the data in the table. After updating the data, the program should retrieve it from the
       database and display it on the console.
 */
package in.ineuron.Test;
import java.io.Serializable;
import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import in.ineuron.Util.HibernateUtil;
import in.ineuron.model.Student1;


public class UpdateApp {

	public static void main(String[] args) {
		Session session=null;
		Transaction transaction=null;
		boolean flag=false;
		
	try {	
		 session = HibernateUtil.getSession();
          if(session!=null)
        	  transaction=session.beginTransaction();
          if(transaction!=null) {
			Student1 student = new Student1();
			student.setSid(5);
			student.setSname("MSD");
			student.setSage(35);
			student.setSaddress("CSK");
			
			session. update(student);
			flag=true;
          }
			
		}
	catch(HibernateException e) {
		e.printStackTrace();
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	finally {
		if(flag) {
			transaction.commit();
		System.out.println("Object Saved To DataBase......");
		
		
		}
		else {
			System.out.println("Object Is not Saved database.......");
		}
		
	}
	
	Scanner scan =new Scanner(System.in);
	System.out.println("Are You Want To Continue Y/N");
	String next = scan.next();
	if(next.equalsIgnoreCase("Y")) {
		GetRecordApp.getRecord();
	}
	else {
		System.out.println("Come Back Again.......");
	}
	HibernateUtil.closeSession(session);
	HibernateUtil.closeSessionFactory();
	
	
	}
}
